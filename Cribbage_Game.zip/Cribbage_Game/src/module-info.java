module Cribbage_Game {
	requires org.junit.jupiter.api;
	requires java.desktop;
}