package ui;

import model.Card;

public interface CardActionListener {
	void onCardSelected(Card card, int i);

}
