package model;

import java.util.Comparator;
import java.util.HashMap;

/**
 * The Card class represents a playing card with a rank and a suit.
 * It provides methods to access its properties and compute values needed for Cribbage scoring.
 */
public class Card implements Comparator {
	private final Suit suit;
	private final Rank rank;
	private static final HashMap<String, Card> pool = new HashMap<>();
	
	private Card(Suit suit, Rank rank) {
		this.suit = suit;
		this.rank = rank;
	}
	
	static {
		for (Suit suit : Suit.values() ) {
			for (Rank rank : Rank.values() ) {
				String key = suit + ":" + rank;
				if (!pool.containsKey(key)) {
					pool.put(key, new Card(suit, rank));
				}
			}
		}
	}
	
	public static Card get(Suit suit, Rank rank) {
		assert suit != null && rank != null;
		return pool.get(suit+":"+rank);
	}
	
	public Suit getSuit() {
		return suit;
	}
	
	public Rank getRank() {
		return rank;
	}
	
	@Override
	public String toString() {
		String symbol;
		if (suit.equals(Suit.SPADES)) {
			symbol = "\u2660";
		}
		else if (suit.equals(Suit.HEARTS)) {
			symbol = "\u2665";
		}
		else if (suit.equals(Suit.DIAMONDS)) {
			symbol = "\u2666";
		}
		else {
			symbol = "\u2663";
		}
		return rank+symbol;
	}

	@Override
	public int compare(Object o1, Object o2) {
		if (o1 == o2) {
			return 0;
		}
		if (o1 instanceof Card) {
			if (o2 instanceof Card) {
				if (((Card) o1).getRank().equals(((Card) o2).getRank())) {
					return 0;
				}
			}
		}
		return 0;
	}
}
	/**
    private String suit;
    private String rank;

    **
     * Constructs a new Card with the specified rank and suit.
     *
     * @param rank the rank of the card (e.g., "A", "2", ..., "K")
     * @param suit the suit of the card (e.g., "Hearts", "Spades")
     *
    public Card(String rank, String suit) {
        this.rank = rank;
        this.suit = suit;
    }

    **
     * Returns the rank of the card.
     *
     * @return the rank as a String
     *
    public String getRank() {
        return rank;
    }

    **
     * Returns the suit of the card.
     *
     * @return the suit as a String
     *
    public String getSuit() {
        return suit;
    }

    **
     * Returns the cribbage value of the card.
     * For cribbage, Ace is 1; cards 2–10 are their face value; face cards count as 10.
     *
     * @return the cribbage value of the card
     *
    public int getCribbageValue() {
        switch(rank) {
            case "A": return 1;
            case "J":
            case "Q":
            case "K": return 10;
            default: return Integer.parseInt(rank);
        }
    }

    **
     * Returns the numeric rank value for evaluating runs.
     * Ace is 1; 2–10 are their face values; Jack is 11; Queen is 12; King is 13.
     *
     * @return the numeric rank value
     *
    public int getRankValue() {
        switch(rank) {
            case "A": return 1;
            case "J": return 11;
            case "Q": return 12;
            case "K": return 13;
            default: return Integer.parseInt(rank);
        }
    }

    **
     * Returns a string representation of the card.
     *
     * @return a string in the format "rank of suit"
     *
    @Override
    public String toString() {
        return rank + " of " + suit;
    }
    */

